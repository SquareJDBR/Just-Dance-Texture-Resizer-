import os
from PIL import Image

# Adicione a mensagem de início
print("Texture Resizer Automatic By SquareJDBR")

# Verifica se as pastas "input" e "output" existem, e cria se não existirem
if not os.path.exists('input'):
    os.makedirs('input')
if not os.path.exists('output'):
    os.makedirs('output')

# Lista de formatos de arquivo de imagem suportados
image_formats = ['jpg', 'jpeg', 'png', 'gif', 'bmp']

# Função para redimensionar uma imagem
def resize_image(input_path, output_path, width, height):
    try:
        with Image.open(input_path) as img:
            img.thumbnail((width, height))
            img.save(output_path)
            print(f'{input_path} redimensionada para {output_path}')
    except Exception as e:
        print(f'Erro ao processar {input_path}: {str(e)}')

# Pasta de entrada
input_folder = 'input'
# Pasta de saída
output_folder = 'output'

# Solicitar ao usuário o tamanho desejado para as imagens redimensionadas
print("Escolha o tamanho para redimensionar a imagem:")
print("1- 128x128(JD2014 Pictos)")
print("2- 256x256(JD2016 - 2020 WII TEXTURES AND IMAGES)")
print("3- 512x512(WII U, NX And PC Pictos And Menuart)")
print("4- 1024x1024(Other Textures)")

size_choice = input("Digite o número da opção desejada: ")

# Mapear a escolha do tamanho para as dimensões correspondentes
size_mapping = {
    '1': (128, 128),
    '2': (256, 256),
    '3': (512, 512),
    '4': (1024, 1024)
}

if size_choice in size_mapping:
    new_width, new_height = size_mapping[size_choice]

    # Percorrer os arquivos na pasta de entrada
    for filename in os.listdir(input_folder):
        file_path = os.path.join(input_folder, filename)
        if os.path.isfile(file_path):
            file_name, file_extension = os.path.splitext(filename)
            file_extension = file_extension[1:].lower()  # Remover o ponto do início da extensão
            if file_extension in image_formats:
                output_file_path = os.path.join(output_folder, filename)
                resize_image(file_path, output_file_path, new_width, new_height)
else:
    print("Escolha inválida. Por favor, escolha uma opção válida.")
